package it.fico.polso

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val zone: ZoneId = ZoneId.systemDefault()
private val hm = DateTimeFormatter.ofPattern("HH:mm")
private val dayFmt = DateTimeFormatter.ofPattern("EEE d MMM", Locale.ITALIAN)

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onRequestPermissions: () -> Unit,
    onOpenHealthConnect: () -> Unit,
) {
    Surface(Modifier.fillMaxSize(), color = Palette.Bg, contentColor = Palette.Text) {
        Box(Modifier.safeDrawingPadding()) {
            when (vm.status) {
                Status.CHECKING -> Centered { Text("…", color = Palette.Muted) }

                Status.UNAVAILABLE -> Centered {
                    Text(
                        "Connessione Salute non è disponibile su questo telefono.",
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onOpenHealthConnect) { Text("Apri Connessione Salute") }
                }

                Status.NEEDS_PERMISSION -> Centered {
                    Text("Polso", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Palette.Steps)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Per mostrare i dati della band serve il permesso di lettura " +
                            "su Connessione Salute. Polso legge soltanto: non scrive e non invia nulla.",
                        textAlign = TextAlign.Center,
                        color = Palette.Muted,
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = onRequestPermissions,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Palette.Steps,
                            contentColor = Color.Black,
                        ),
                    ) { Text("Concedi accesso") }
                }

                Status.READY -> Dashboard(vm, onRequestPermissions, onOpenHealthConnect)
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

@Composable
private fun Dashboard(
    vm: DashboardViewModel,
    onRequestPermissions: () -> Unit,
    onOpenHealthConnect: () -> Unit,
) {
    val d = vm.data
    val isToday = vm.day == LocalDate.now()

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { Header(vm, isToday) }

        if (d == null) {
            item {
                Text(
                    if (vm.loading) "Caricamento…" else "Nessun dato per questo giorno.",
                    color = Palette.Muted,
                    modifier = Modifier.padding(8.dp),
                )
            }
        } else {
            d.hourlySteps?.let { hours ->
                item { StepsCard(d, hours, if (isToday) LocalTime.now().hour else null) }
            }
            d.week?.let { week -> item { WeekCard(week, d.day) } }
            d.heart?.let { h -> item { HeartCard(d, h) } }
            d.sleep?.let { s -> item { SleepCard(s) } }
            d.hrv?.let { list -> item { TrendCard("Variabilità cardiaca (HRV)", Palette.Hrv, list, "ms", 0) } }
            d.resting?.takeIf { d.heart == null }?.let { list ->
                item { TrendCard("Battito a riposo", Palette.Resting, list, "bpm", 0) }
            }
            d.spo2?.let { list -> item { DayValuesCard("Ossigeno nel sangue (SpO₂)", Palette.Spo2, list, "%", d) } }
            d.respiration?.let { list ->
                item { DayValuesCard("Frequenza respiratoria", Palette.Breath, list, "atti/min", d) }
            }
            d.exercises?.let { list -> item { WorkoutsCard(list) } }
        }

        item { Footer(vm, onRequestPermissions, onOpenHealthConnect) }
    }
}

@Composable
private fun Header(vm: DashboardViewModel, isToday: Boolean) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Polso", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Palette.Steps)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.shiftDay(-1) }) { Text("‹", fontSize = 26.sp, color = Palette.Text) }
            Text(
                text = when (vm.day) {
                    LocalDate.now() -> "Oggi"
                    LocalDate.now().minusDays(1) -> "Ieri"
                    else -> vm.day.format(dayFmt).replaceFirstChar { it.uppercase() }
                },
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.width(96.dp),
                textAlign = TextAlign.Center,
            )
            TextButton(onClick = { vm.shiftDay(1) }, enabled = !isToday) {
                Text("›", fontSize = 26.sp, color = if (isToday) Palette.Grid else Palette.Text)
            }
        }
        if (!isToday) {
            TextButton(onClick = { vm.goToday() }) { Text("Torna a oggi", color = Palette.Steps) }
        }
        if (vm.loading) {
            LinearProgressIndicator(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                color = Palette.Steps,
                trackColor = Palette.Track,
            )
        }
    }
}

@Composable
private fun Card(title: String, color: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Palette.Card)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(Modifier.width(8.dp))
            Text(title, fontSize = 14.sp, color = Palette.Muted, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun Stat(value: String, label: String, color: Color = Palette.Text, big: Boolean = false) {
    Column {
        Text(value, fontSize = if (big) 34.sp else 20.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 12.sp, color = Palette.Muted)
    }
}

@Composable
private fun StepsCard(d: DayData, hours: List<Long>, currentHour: Int?) {
    Card("Passi", Palette.Steps) {
        Row(verticalAlignment = Alignment.Bottom) {
            Stat(fmtInt(d.totalSteps ?: 0L), "passi", Palette.Steps, big = true)
            Spacer(Modifier.weight(1f))
            d.distanceKm?.let {
                Stat(String.format(Locale.ITALY, "%.1f", it), "km")
                Spacer(Modifier.width(18.dp))
            }
            (d.activeKcal ?: d.totalKcal)?.let {
                Stat(fmtInt(it.toLong()), if (d.activeKcal != null) "kcal attive" else "kcal")
            }
        }
        Spacer(Modifier.height(18.dp))
        HourlyStepsChart(hours, currentHour)
        val best = hours.indices.maxByOrNull { hours[it] }
        if (best != null && hours[best] > 0) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Ora più attiva: %02d:00–%02d:00".format(best, (best + 1) % 24),
                fontSize = 12.sp,
                color = Palette.Muted,
            )
        }
    }
}

@Composable
private fun WeekCard(week: List<Pair<LocalDate, Long>>, selected: LocalDate) {
    val avg = week.map { it.second }.average().toLong()
    Card("Ultimi 7 giorni", Palette.Steps) {
        Stat(fmtInt(avg), "passi in media al giorno")
        Spacer(Modifier.height(16.dp))
        WeekBars(week, selected)
    }
}

@Composable
private fun HeartCard(d: DayData, h: HeartInfo) {
    val restingToday = d.resting?.lastOrNull { it.time.atZone(zone).toLocalDate() == d.day }
    Card("Battito", Palette.Heart) {
        Row {
            Stat("${h.min}", "min", Palette.Text)
            Spacer(Modifier.width(22.dp))
            Stat("${h.avg}", "media", Palette.Heart)
            Spacer(Modifier.width(22.dp))
            Stat("${h.max}", "max", Palette.Text)
            restingToday?.let {
                Spacer(Modifier.weight(1f))
                Stat("${it.value.toLong()}", "a riposo", Palette.Resting)
            }
        }
        Spacer(Modifier.height(16.dp))
        val daySec = 86_400f
        val pts = h.bins.map {
            Duration.between(d.dayStart, it.time).seconds / daySec to it.value.toFloat()
        }
        val lo = (h.min - 5).toFloat()
        val hi = (h.max + 5).toFloat()
        LineChart(pts, Palette.Heart, lo, hi, height = 150.dp, gap = 30f / 1440f)
        HourAxis()
        Text(
            "bpm · scala ${lo.toInt()}–${hi.toInt()}",
            fontSize = 11.sp,
            color = Palette.Muted,
            modifier = Modifier.padding(top = 6.dp),
        )
        d.resting?.takeIf { it.size >= 2 }?.let { list ->
            Spacer(Modifier.height(18.dp))
            Text("Battito a riposo, 30 giorni", fontSize = 12.sp, color = Palette.Muted)
            Spacer(Modifier.height(6.dp))
            Sparkline(list, Palette.Resting)
        }
    }
}

@Composable
private fun Sparkline(list: List<TimedValue>, color: Color) {
    val lo = list.minOf { it.value }.toFloat()
    val hi = list.maxOf { it.value }.toFloat()
    val pad = ((hi - lo) * 0.15f).coerceAtLeast(1f)
    val first = list.first().time
    val span = Duration.between(first, list.last().time).seconds.coerceAtLeast(1L).toFloat()
    val pts = list.map { Duration.between(first, it.time).seconds / span to it.value.toFloat() }
    LineChart(pts, color, lo - pad, hi + pad, height = 70.dp, gridColumns = 6, dots = list.size <= 31)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(list.first().time.atZone(zone).format(DateTimeFormatter.ofPattern("d MMM", Locale.ITALIAN)), fontSize = 10.sp, color = Palette.Muted)
        Text(
            "min ${lo.toInt()} · max ${hi.toInt()}",
            fontSize = 10.sp,
            color = Palette.Muted,
        )
        Text(list.last().time.atZone(zone).format(DateTimeFormatter.ofPattern("d MMM", Locale.ITALIAN)), fontSize = 10.sp, color = Palette.Muted)
    }
}

@Composable
private fun SleepCard(s: SleepInfo) {
    val total = Duration.between(s.start, s.end)
    val byLevel = s.stages
        .groupBy { sleepLevel(it.type) }
        .mapValues { (_, segs) -> segs.fold(Duration.ZERO) { acc, seg -> acc + Duration.between(seg.start, seg.end) } }
    val asleep = total - (byLevel[SleepLevel.AWAKE] ?: Duration.ZERO)
    Card("Sonno", Palette.Rem) {
        Row(verticalAlignment = Alignment.Bottom) {
            Stat(fmtDuration(asleep), "dormito", Palette.Rem, big = true)
            Spacer(Modifier.weight(1f))
            Stat(
                "${s.start.atZone(zone).format(hm)}–${s.end.atZone(zone).format(hm)}",
                "a letto",
            )
        }
        Spacer(Modifier.height(16.dp))
        Hypnogram(s)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 64.dp, top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(s.start.atZone(zone).format(hm), fontSize = 10.sp, color = Palette.Muted)
            Text(s.end.atZone(zone).format(hm), fontSize = 10.sp, color = Palette.Muted)
        }
        if (byLevel.size > 1) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SleepLevel.values().forEach { lvl ->
                    val dur = byLevel[lvl] ?: Duration.ZERO
                    val pct = if (total.seconds > 0) dur.seconds * 100 / total.seconds else 0
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(fmtDuration(dur), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = lvl.color)
                        Text("${lvl.label} · $pct%", fontSize = 10.sp, color = Palette.Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrendCard(title: String, color: Color, list: List<TimedValue>, unit: String, decimals: Int) {
    val last = list.last()
    val avg = list.map { it.value }.average()
    Card(title, color) {
        Row(verticalAlignment = Alignment.Bottom) {
            Stat(fmtDec(last.value, decimals) + " $unit", "ultima · " + last.time.atZone(zone).format(DateTimeFormatter.ofPattern("d MMM HH:mm", Locale.ITALIAN)), color)
            Spacer(Modifier.weight(1f))
            Stat(fmtDec(avg, decimals) + " $unit", "media 30 giorni")
        }
        if (list.size >= 2) {
            Spacer(Modifier.height(14.dp))
            Sparkline(list, color)
        }
    }
}

@Composable
private fun DayValuesCard(title: String, color: Color, list: List<TimedValue>, unit: String, d: DayData) {
    val lo = list.minOf { it.value }
    val hi = list.maxOf { it.value }
    Card(title, color) {
        Row {
            Stat(fmtDec(list.map { it.value }.average(), 0) + " $unit", "media", color)
            Spacer(Modifier.width(22.dp))
            Stat(fmtDec(lo, 0), "min")
            Spacer(Modifier.width(22.dp))
            Stat(fmtDec(hi, 0), "max")
        }
        if (list.size >= 2) {
            Spacer(Modifier.height(14.dp))
            val pts = list.map { Duration.between(d.dayStart, it.time).seconds / 86_400f to it.value.toFloat() }
            val pad = ((hi - lo) * 0.2).coerceAtLeast(1.0)
            LineChart(pts, color, (lo - pad).toFloat(), (hi + pad).toFloat(), height = 80.dp, gap = 90f / 1440f, dots = true)
            HourAxis()
        }
    }
}

@Composable
private fun WorkoutsCard(list: List<ExerciseInfo>) {
    Card("Allenamenti", Palette.Workout) {
        list.forEachIndexed { i, e ->
            if (i > 0) Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${e.start.atZone(zone).format(hm)}–${e.end.atZone(zone).format(hm)}",
                        fontSize = 12.sp,
                        color = Palette.Muted,
                    )
                }
                Text(fmtDuration(Duration.between(e.start, e.end)), color = Palette.Workout, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Footer(
    vm: DashboardViewModel,
    onRequestPermissions: () -> Unit,
    onOpenHealthConnect: () -> Unit,
) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(
            "I dati arrivano da Connessione Salute (Huawei Health → Health Sync). " +
                "Lo stress non è disponibile: Connessione Salute non lo prevede. " +
                "Le sezioni senza dati non vengono mostrate.",
            fontSize = 11.sp,
            color = Palette.Muted,
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { vm.refresh() }, modifier = Modifier.weight(1f)) {
                Text("Aggiorna", color = Palette.Text)
            }
            OutlinedButton(onClick = onOpenHealthConnect, modifier = Modifier.weight(1f)) {
                Text("Conn. Salute", color = Palette.Text)
            }
        }
        if (vm.missingPermissions) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onRequestPermissions, modifier = Modifier.fillMaxWidth()) {
                Text("Concedi i permessi mancanti", color = Palette.Text)
            }
        }
    }
}

private fun fmtDec(v: Double, decimals: Int): String =
    String.format(Locale.ITALY, "%.${decimals}f", v)
