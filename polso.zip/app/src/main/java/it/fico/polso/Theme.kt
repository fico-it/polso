package it.fico.polso

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg = Color(0xFF0E1116)
    val Card = Color(0xFF181C23)
    val Track = Color(0xFF242A33)
    val Grid = Color(0xFF2A303A)
    val Text = Color(0xFFF2F4F7)
    val Muted = Color(0xFF8A93A3)

    val Steps = Color(0xFFB8F24A)   // chartreuse
    val Heart = Color(0xFFFF5C6C)
    val Resting = Color(0xFFFF9AA5)
    val Hrv = Color(0xFFFFD166)
    val Spo2 = Color(0xFF4FD1C5)
    val Breath = Color(0xFF7FD6FF)
    val Workout = Color(0xFFFF9F43)

    val Awake = Color(0xFFFFB454)
    val Rem = Color(0xFFB48CFF)
    val Light = Color(0xFF7FA8FF)
    val Deep = Color(0xFF4A55C9)
}

@Composable
fun PolsoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Steps,
            onPrimary = Color.Black,
            background = Palette.Bg,
            surface = Palette.Card,
            onSurface = Palette.Text,
            onBackground = Palette.Text,
        ),
        content = content,
    )
}
