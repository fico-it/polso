package it.fico.polso

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.health.connect.client.HealthConnectClient
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class Status { CHECKING, UNAVAILABLE, NEEDS_PERMISSION, READY }

class DashboardViewModel(app: Application) : AndroidViewModel(app) {

    var status by mutableStateOf(Status.CHECKING)
        private set
    var day by mutableStateOf(LocalDate.now())
        private set
    var data by mutableStateOf<DayData?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var granted by mutableStateOf<Set<String>>(emptySet())
        private set

    private var repo: HealthRepo? = null
    private var loadJob: Job? = null

    fun refresh() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            if (HealthConnectClient.getSdkStatus(ctx) != HealthConnectClient.SDK_AVAILABLE) {
                status = Status.UNAVAILABLE
                return@launch
            }
            val r = repo ?: HealthRepo(ctx).also { repo = it }
            granted = try {
                r.granted()
            } catch (e: Exception) {
                emptySet()
            }
            if (granted.isEmpty()) {
                status = Status.NEEDS_PERMISSION
                return@launch
            }
            status = Status.READY
            load()
        }
    }

    private fun load() {
        val r = repo ?: return
        val target = day
        val perms = granted
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            loading = true
            val result = try {
                r.load(target, perms)
            } catch (e: Exception) {
                null
            }
            if (target == day) data = result
            loading = false
        }
    }

    fun shiftDay(delta: Long) {
        val next = day.plusDays(delta)
        if (next.isAfter(LocalDate.now())) return
        day = next
        load()
    }

    fun goToday() {
        day = LocalDate.now()
        load()
    }

    val missingPermissions: Boolean
        get() = !granted.containsAll(HealthRepo.PERMISSIONS)
}
